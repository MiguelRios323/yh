Generador de memes de la [Oficina del Presidente Electo de Argentina](https://twitter.com/opearg)

# DISCLAIMER
Esto está hecho a forma de chiste, no tiene ninguna intención de ofender a nadie. Si no te gusta, no lo uses.